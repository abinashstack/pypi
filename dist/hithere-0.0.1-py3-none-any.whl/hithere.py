def say_hi(name=None):
    if name is None:
        return "Hi there!"
    else:
        return f"Hii ,{name}!!"