## Usage

* python

* from hithere import say_hi


# Generate "Hi, There!"

* say_hi()

# Generate "Hi ,Everybody"

say_hi("Everybody")


# Author : Abinash Gogoi
 

